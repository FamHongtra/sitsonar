package excelexam;

import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFileChooser;
import jxl.*;
import jxl.write.*;
import jxl.write.Number;

public class ExcelRoute1 {

    public static void main(String[] args) {
        setBusStop(10);
    }

    public static void setBusStop(int numberBusStop) {
        JFileChooser file = new JFileChooser();
        file.showSaveDialog(file);
        try {

            WritableWorkbook workbook = Workbook.createWorkbook(new File(file.getSelectedFile() + ".xls"));

            // สำหรับฟ้อน ละฟอร์แมต
            WritableFont cellFont = new WritableFont(WritableFont.ARIAL, 16);
            cellFont.setBoldStyle(WritableFont.BOLD);

            WritableFont cellFont2 = new WritableFont(WritableFont.TIMES, 12);

            WritableCellFormat cellFormatBold = new WritableCellFormat(cellFont);
            cellFormatBold.setBackground(jxl.format.Colour.WHITE);
            cellFormatBold.setAlignment(jxl.format.Alignment.CENTRE);
            cellFormatBold.setVerticalAlignment(jxl.format.VerticalAlignment.CENTRE);

            WritableCellFormat cellFormat = new WritableCellFormat(cellFont2);
            cellFormat.setBackground(jxl.format.Colour.WHITE);
            cellFormat.setAlignment(jxl.format.Alignment.CENTRE);
            cellFormat.setVerticalAlignment(jxl.format.VerticalAlignment.CENTRE);

            // สำหรับหน้า sheet
            WritableSheet sheet = workbook.createSheet("sheet", 0);

            // ขยายคอลัมป์
            sheet.setColumnView(0, 13);
            sheet.setColumnView(1, 5);
            sheet.setColumnView(2, 15);
            sheet.setColumnView(3, 10);
            sheet.setColumnView(4, 10);
            sheet.setColumnView(5, 10);
            sheet.setColumnView(6, 10);
            sheet.setColumnView(7, 10);
            sheet.setColumnView(8, 10);
            sheet.setColumnView(9, 10);
            sheet.setColumnView(10, 10);
            sheet.setColumnView(11, 10);
            sheet.setColumnView(12, 13);
            sheet.setColumnView(13, 10);
            sheet.setColumnView(14, 10);
            sheet.setColumnView(15, 13);

            //การ merge col และ row โดยพารามิเตอร์ 1 และ 3 คือ col พารามิเตอร์ 2 และ 4 คือ row
            // สรุปรายงานการใช้บริการรถพลังงานไฟฟ้า มจธ.   คันที่  1 วิ่งตามเส้นทางที่  1  c 0-16 r 0-1
            sheet.mergeCells(0, 0, 15, 1);
            Label label = new Label(0, 0, " สรุปรายงานการใช้บริการรถพลังงานไฟฟ้า มจธ.   คันที่  1 วิ่งตามเส้นทางที่  1", cellFormatBold);

            sheet.addCell(label);

            // วันที่ c 0-0 r 2-3 แถว A
            sheet.mergeCells(0, 2, 0, 3);
            label = new Label(0, 2, "วันที่", cellFormat);
            sheet.addCell(label);
            // 1/9/59
            sheet.mergeCells(0, 4, 0, 4);
            label = new Label(0, 4, "1/9/59", cellFormat);
            sheet.addCell(label);
            // 2/9/59
            sheet.mergeCells(0, 5, 0, 5);
            label = new Label(0, 5, "2/9/59", cellFormat);
            sheet.addCell(label);
            // 5/9/59
            sheet.mergeCells(0, 6, 0, 6);
            label = new Label(0, 6, "5/9/59", cellFormat);
            sheet.addCell(label);
            // 6/9/59
            sheet.mergeCells(0, 7, 0, 7);
            label = new Label(0, 7, "6/9/59", cellFormat);
            sheet.addCell(label);
            // 7/9/59
            sheet.mergeCells(0, 8, 0, 8);
            label = new Label(0, 8, "7/9/59", cellFormat);
            sheet.addCell(label);
            // 8/9/59
            sheet.mergeCells(0, 9, 0, 9);
            label = new Label(0, 9, "8/9/59", cellFormat);
            sheet.addCell(label);
            // 9/9/59
            sheet.mergeCells(0, 10, 0, 10);
            label = new Label(0, 10, "9/9/59", cellFormat);
            sheet.addCell(label);
            // 12/9/59
            sheet.mergeCells(0, 11, 0, 11);
            label = new Label(0, 11, "12/9/59", cellFormat);
            sheet.addCell(label);
            // 13/9/59
            sheet.mergeCells(0, 12, 0, 12);
            label = new Label(0, 12, "13/9/59", cellFormat);
            sheet.addCell(label);
            // 14/9/59
            sheet.mergeCells(0, 13, 0, 13);
            label = new Label(0, 13, "14/9/59", cellFormat);
            sheet.addCell(label);
            // 15/9/59
            sheet.mergeCells(0, 14, 0, 14);
            label = new Label(0, 14, "15/9/59", cellFormat);
            sheet.addCell(label);
            // 16/9/59
            sheet.mergeCells(0, 15, 0, 15);
            label = new Label(0, 15, "16/9/59", cellFormat);
            sheet.addCell(label);
            // 19/9/59
            sheet.mergeCells(0, 16, 0, 16);
            label = new Label(0, 16, "19/9/59", cellFormat);
            sheet.addCell(label);
            // 20/9/59
            sheet.mergeCells(0, 17, 0, 17);
            label = new Label(0, 17, "20/9/59", cellFormat);
            sheet.addCell(label);
            // 21/9/59
            sheet.mergeCells(0, 18, 0, 18);
            label = new Label(0, 18, "21/9/59", cellFormat);
            sheet.addCell(label);
            // 22/9/59
            sheet.mergeCells(0, 19, 0, 19);
            label = new Label(0, 19, "22/9/59", cellFormat);
            sheet.addCell(label);
            // 23/9/59
            sheet.mergeCells(0, 20, 0, 20);
            label = new Label(0, 20, "23/9/59", cellFormat);
            sheet.addCell(label);
            // 26/9/59
            sheet.mergeCells(0, 21, 0, 21);
            label = new Label(0, 21, "26/9/59", cellFormat);
            sheet.addCell(label);
            // 27/9/59
            sheet.mergeCells(0, 22, 0, 22);
            label = new Label(0, 22, "27/9/59", cellFormat);
            sheet.addCell(label);
            // 28/9/59
            sheet.mergeCells(0, 23, 0, 23);
            label = new Label(0, 23, "28/9/59", cellFormat);
            sheet.addCell(label);
            // 29/9/59
            sheet.mergeCells(0, 24, 0, 24);
            label = new Label(0, 24, "29/9/59", cellFormat);
            sheet.addCell(label);
            // 30/9/59
            sheet.mergeCells(0, 25, 0, 25);
            label = new Label(0, 25, "30/9/59", cellFormat);
            sheet.addCell(label);

            // รวม
            sheet.mergeCells(0, 26, 1, 26);
            label = new Label(0, 26, "รวม", cellFormatBold);
            sheet.addCell(label);

            // คันที่ c 1 r 2-3 แถว B
            sheet.mergeCells(1, 2, 1, 3);
            label = new Label(1, 2, "คันที่", cellFormat);
            sheet.addCell(label);
            //เฉพาะคันที่1
            for (int i = 4; i < 26; i++) {
                Number number = new Number(1, i, 1, cellFormat);
                sheet.addCell(number);
            }
            // จำนวนรอบ c 2 r 2-3 แถว C
            sheet.mergeCells(2, 2, 2, 3);
            label = new Label(2, 2, "จำนวนรอบ", cellFormat);
            sheet.addCell(label);
            //รอบ
            Number number = new Number(2, 4, 45, cellFormat);
            // sheet.addCell(number);

            // จำนวนผู้ใช้บริการ c 3-8 r 2 D E F G H I
            sheet.mergeCells(3, 2, 8, 2);
            label = new Label(3, 2, "จำนวนผู้ใช้บริการ (คน)", cellFormat);
            sheet.addCell(label);

            /*   // จุดที่1 c 3 r 3 แถวD
            label = new Label(3, 3, "จุดที่ 1", cellFormat);
            sheet.addCell(label);
            //จุดที่1
            number = new Number(3, 4, 308, cellFormat);
            sheet.addCell(number);
            
            // จุดที่2 c 4 r 3 แถวE
            label = new Label(4, 3, "จุดที่ 2", cellFormat);
            sheet.addCell(label);
            //จุดที่2
            number = new Number(4, 4, 166, cellFormat);
            sheet.addCell(number);
            
            // จุดที่3 c 5 r 3 แถวF
            label = new Label(5, 3, "จุดที่ 3", cellFormat);
            sheet.addCell(label);
            //จุดที่3
            number = new Number(5, 4, 172, cellFormat);
            sheet.addCell(number);
            
            // จุดที่4 c 6 r 3 แถวG
            label = new Label(6, 3, "จุดที่ 4", cellFormat);
            sheet.addCell(label);
            //จุดที่4
            number = new Number(6, 4, 73, cellFormat);
            sheet.addCell(number);
            
            // จุดที่5 c 7 r 3 แถวH
            label = new Label(7, 3, "จุดที่ 5", cellFormat);
            sheet.addCell(label);
            //จุดที่5
            number = new Number(7, 4, 81, cellFormat);
            sheet.addCell(number);*/
            for (int i = 0; i < numberBusStop; i++) {
                char box = 'D';
                System.out.println("จุดที่ " + (1 + i) + "พิกัด " + (3 + i) + "," + "3");//เริ่มต้น fix ให้ช่องจุดที่1เริ่มที่ ช่อง3,3 แล้วเ
                //แล้วเราก็ให้วนลูปแล้วก้บวกเข้าเลขช่องของเรา 
                label = new Label((3 + i), 3, "จุดที่ " + (1 + i), cellFormat);
                sheet.addCell(label);

                box++;
            }
            // จุดอื่น c 8 r 3 แถวI
            //                3 คือ ค่าช่องที่เราฟิก+กับจน.ช่องที่เรากรอก+0เพราะ มันยังไม่ยังเลื่อน แต่ต่อๆไปมันจะต้องถัดไปเรื่อยๆ 
//            label = new Label(3 + numberBusStop + 0, 3, "จุดอื่นๆ", cellFormat);
//            sheet.addCell(label);

            // รวม c9 r2-3 แถวJ
            sheet.mergeCells(3 + numberBusStop + 1, 2, 3 + numberBusStop + 1, 3);
            System.out.println("รวมคนตน.merg" + (3 + numberBusStop + 1) + ",2");
            // 3 คือ ค่าช่องที่เราฟิก+กับจน.ช่องที่เรากรอก+1เพราะ เลื่อนจากช่องจุด ไปสองช่องไม่นับช่องบนที่เป็น0 และต่อๆไปมันจะต้องถัดไปเรื่อยๆ
            label = new Label(3 + numberBusStop + 0, 2, "รวม(คน)", cellFormat);
            sheet.addCell(label);
            // รวม
//            number = new Number(3+numberBusStop+1, 4, 800, cellFormat);
//            sheet.addCell(number);

            // ไมล์ c10-11 r2 แถวKL
            sheet.mergeCells(3 + numberBusStop + 1, 2, 3 + numberBusStop + 1, 2);
            label = new Label(3 + numberBusStop + 1, 2, "ไมล์", cellFormat);
            sheet.addCell(label);



            // มิเตอร์ไฟฟ้า c13-14 r2 แถวNO
            sheet.mergeCells(3 + numberBusStop + 2, 2, 3 + numberBusStop + 2, 2);
            label = new Label(3 + numberBusStop + 2, 2, "มิเตอร์ไฟฟ้า", cellFormat);
            sheet.addCell(label);

            // เริ่มต้น c13 r3 แถว N
//            label = new Label(3 + numberBusStop + 5, 3, "เริ่มต้น", cellFormat);
//            sheet.addCell(label);
//            // เริ่มต้น
//            number = new Number(3 + numberBusStop + 5, 4, 520, cellFormat);
//            sheet.addCell(number);

            // สิ้นสุด c14 r3 แถว O
//            label = new Label(3 + numberBusStop + 6, 3, "สิ้นสุด", cellFormat);
//            sheet.addCell(label);
            // สิ้นสุด
//            number = new Number(3 + numberBusStop + 6, 4, 536, cellFormat);
//            sheet.addCell(number);

            // จำนวนไฟ c15 r2-3 แถวP
//            sheet.mergeCells(3 + numberBusStop + 7, 2, 3 + numberBusStop + 7, 3);
//            label = new Label(3 + numberBusStop + 7, 2, "จำนวนไฟ", cellFormat);
//            sheet.addCell(label);
//            // จำนวนไฟ
//            number = new Number(3 + numberBusStop + 7, 4, 16, cellFormat);
//            sheet.addCell(number);

            //Number number = new Number(0,1,1/9/59);
            //sheet.addCell(number);
            //การเปลี่ยนสีทั้งแบล็คกราวน์และสีฟ้อน
            /*WritableFont cellFont = new WritableFont(WritableFont.ARIAL, 16);
            cellFont.setColour(jxl.format.Colour.AQUA);
            cellFont.setBoldStyle(WritableFont.BOLD);
            WritableCellFormat cellFormat = new WritableCellFormat(cellFont);
            cellFormat.setBackground(jxl.format.Colour.BLUE);
            label = new Label(5,5,"A lable record", cellFormat);
            
            sheet.mergeCells(5, 5, 7, 5);
            sheet.addCell(label);*/
            Connection con = ConnectionBuilder.getConnection();
            PreparedStatement psm = con.prepareStatement("SELECT * FROM workdate JOIN workround on workdate.workdate_id=workround.workdate_id WHERE MONTH(workdate) = ? AND YEAR(workdate)=?");
            psm.setInt(1, 4);
            psm.setInt(2, 2017);

            ResultSet rs = psm.executeQuery();

            for (int i = 0; rs.next(); i++) {//เขียนแถว
                SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/YY");
                // System.out.println(rs.getInt("workround_id")+"|"+sdf.format(rs.getDate("workdate")));
                //System.out.println(rs.getInt("workround")+"|"+sdf.format(rs.getDate("workround")));

                Number number1 = new Number(2, 4 + i, rs.getInt("workround"), cellFormat);
                sheet.addCell(number1);//จำนวนรอบ
                /////////////////////////////
               
                ////////////////////////////
                number = new Number(3 + numberBusStop + 1, 4 + i, rs.getInt("miles"), cellFormat);
                sheet.addCell(number);//จุดเริ่มต้น
                
                number = new Number(3 + numberBusStop + 2, 4 + i, rs.getInt("electricity"), cellFormat);
                sheet.addCell(number);
                //////////////////////////////
               


            }
            psm = con.prepareStatement("SELECT * FROM workdate JOIN workround on workdate.workdate_id=workround.workdate_id WHERE MONTH(workdate) = ? AND YEAR(workdate)=?");
            psm.setInt(1, 4);
            psm.setInt(2, 2017);
            rs = psm.executeQuery();
            for (int j = 0; rs.next(); j++) {//j=ค่าตามวันที่มี
                for (int i = 0; i < numberBusStop; i++) {//i=ค่าป้าย
                    char box = 'D';
                    System.out.println("จุดที่ " + (1 + i) + "พิกัด " + (3 + i) + "," + "3");//เริ่มต้น fix ให้ช่องจุดที่1เริ่มที่ ช่อง3,3 แล้วเ
                    //แล้วเราก็ให้วนลูปแล้วก้บวกเข้าเลขช่องของเรา 
                    number = new Number((3 + i), 4 + j, rs.getInt("newpassengers"), cellFormat);//วนลูปแสดงค่าจากdatabase ตามค่าที่กรอก
                    sheet.addCell(number);

                    box++;
                }//รวมค่าในแนวนอนของป้ายจุดที่
                double num =0;
                for (int i=0;i<numberBusStop;i++ ) {
                    Sheet firstSheet = workbook.getSheet(0);
                    Cell a1 = firstSheet.getCell(3+i,4+j);
                    NumberCell numCell = (NumberCell) a1;
                    num += numCell.getValue();
                    
                }
                number = new Number(3 + numberBusStop + 0, 4 + j, num, cellFormat);//วนลูปแสดงค่าจากdatabase ตามค่าที่กรอก
                sheet.addCell(number);
                System.out.println(num);
                
            }

            workbook.write();
            workbook.close();
        } catch (WriteException e) {
            System.out.println("ลืมโค้ด");
        } catch (IOException e) {
            System.out.println("เขียนไม่ได้");
        } catch (SQLException ex) {
            Logger.getLogger(ExcelRoute1.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}
