package excelexam;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;


/**
 *
 * @author F O L D E R
 */
public class ConnectionBuilder {

    public static Connection getConnection() {
        Connection con = null;
        try {
            Class.forName("org.mariadb.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mariadb://10.4.56.23:3306/ebusplus-g1", "ebusplus", "ebusplus2017");
        } catch (ClassNotFoundException e) {
            System.out.println(e);
        } catch (SQLException e) {
            System.out.println(e);
        }
        return con;
    }
    
//    public static void main(String[] args) throws SQLException {
//        Connection con = getConnection();
//        String sql = "select * from user where user_id = ?";
//        PreparedStatement pstm = con.prepareStatement(sql);
//        pstm.setInt(1, 1);
//        ResultSet rs = pstm.executeQuery();
//        while(rs.next()){
////                Bus b = new Bus();
////                b.setBus_id(rs.getInt("bus_id"));
////                b.setBus_name(rs.getString("bus_name"));
////                b.setRoutebs1(rs.getInt("routebs1"));
////                b.setRoutebs2(rs.getInt("routebs2"));
////                b.setRoutebs3(rs.getInt("routebs3"));
////                b.setRoutebs4(rs.getInt("routebs4"));
////                b.setRoutebs5(rs.getInt("routebs5"));
////                System.out.println("Route: "+ b.getBus_name());
//                   System.out.println(rs.getString("firstname"));
//            }
//        
//       
//        con.close();
//        
//    }
    
    public static void main(String[] args) throws SQLException {
        java.util.Date current = new java.util.Date();
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        df.setTimeZone(TimeZone.getTimeZone("Asia/Bangkok"));
        int day = current.getDay();
        int date = current.getDate();
        int month = current.getMonth()+1;
        int year = current.getYear()+1900;
        int hr = current.getHours();
        int min = current.getMinutes();
        int sec = current.getSeconds();
        
        
//df.setTimeZone(TimeZone.getDefault());
        String curdatetime = df.format(current);

        String timest = year+"-"+month+"-"+date+" "+hr+":"+min+":"+sec;
        System.out.println(year+"-"+month+"-"+date+" "+hr+":"+min+":"+sec);
        Connection con = getConnection();
        String sql = "insert into datenaja (date,car) values (?,1)";
        PreparedStatement pstm = con.prepareStatement(sql);
        pstm.setString(1, curdatetime);
        pstm.execute();
//        
        
        String sql2 = "select * from datenaja where car=? order by date desc limit 1" ;
        PreparedStatement pstm2 = con.prepareStatement(sql2);
        pstm2.setInt(1, 1);
        ResultSet rs2 = pstm2.executeQuery();
        while (rs2.next()) {
            System.out.println(rs2.getDate("date"));
            System.out.println(rs2.getTime("date"));
        }
    }
}